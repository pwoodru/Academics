package cpsc2150.sets;

/**
 * correspondences length = set.length
 * @invariants [set contains no duplicate values]
 */
public class ArraySet<T> extends SetAbs<T> implements ISet<T> {

    private T[] set;
    private int depth;
    private static final int MAX = 100;

    /**
     * @post: [Set is empty]
     */
    public ArraySet() {
        set = (T[]) new Object[MAX];
        depth = -1;
    }

    public void add(T val) {
        depth++;
        set[depth] = val;
    }

    public T remove() {
        T front = set[0];
        for(int i = 0; i < set.length; i++) {
            if (set.length + 1 <= MAX_SIZE - 2) {
                set[i] = set[i+1];
            }
        }
        depth--;
        return front;
    }

    public boolean contains(T val) {
        int i;
        for (i = 0; i < set.length; i++) {
            if (set[i] == val) {
                return true;
            }
        }
        return false;
    }

    public int getSize() {
        return set.length;
    }
}
