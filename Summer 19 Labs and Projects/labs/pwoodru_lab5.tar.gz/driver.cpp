/****************
Patrick Woodrum
pwoodru
CpSc 1020 Sm19
Lab 5
TA: Nushrat H
****************/

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "GradeCalculator.h"
using namespace std;

int main (int argc, char* argv[]) {

  //Command line amount check
  if (argc < 4) {
    cout << "Not enough command line arguments. Exiting." << endl;
    return -1;
  }

  //Open files and check that they opened
  ifstream input1;
  input1.open("test.txt");
  if (!input1.is_open()) {
    return -1;
  }

  ifstream input2;
  input2.open("gradesSoFar.txt");
  if (!input2.is_open()) {
    return -1;
  }

  ofstream out;
  out.open("output.txt");
  if (!out.is_open()) {
    return -1;
  }

  //Table 1
  //Read from input how many categories there will be
  int numCat;
  input1 >> numCat;
  //Allocate memory for an array of category structs
  //using number of categories just read in from input
  cat_t* cats = new cat_t[numCat];

  readGradeBasis(input1, cats, numCat);
  printGradeBasis(out, cats, numCat);

  //Table 2
  int numCat2;
  input2 >> numCat2;
  cat_t* cats2 = new cat_t[numCat2];

  readNumGrades(input2, out, cats2, numCat2);

  //Table 3
  //uses info from table 2 variables
  //need to fill in missing values
  int i;
  for (i = 0; i < numCat2; i++) {
    cats2[i].percentEach = cats[i].percentEach;
  }
  printPoints(out, cats2, numCat2);

  //Table 4 and final print
  printPercent(out, cats2, numCat2);

  //release allocated memory
  delete [] cats;
  delete [] cats2;
return 0;
}
