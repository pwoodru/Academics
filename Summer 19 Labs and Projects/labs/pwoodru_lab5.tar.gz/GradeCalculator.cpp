/****************
Patrick Woodrum
pwoodru
CpSc 1020 Sm19
Lab 5
TA: Nushrat H
****************/
#include "GradeCalculator.h"
using namespace std;

//read info from input for Table 1
void readGradeBasis(ifstream& input1, cat_t* cat, int numCat) {
  int i;
  //loop reads in the name, totalPercent, number of assignments, and
  //weight of each category on the final grade
  for (i = 0; i < numCat; i++) {
    input1 >> cat[i].name;
    input1 >> cat[i].totalPercent;
    input1 >> cat[i].howMany;
    //had to cast the integers as doubles in order to get weights
    //accurate up to 4 decimal points
    cat[i].percentEach = static_cast<double>(cat[i].totalPercent)
     / static_cast<double>(cat[i].howMany);
  }
}

//prints the content for table 1 using info from readGradeBasis
void printGradeBasis(ofstream& out, cat_t* cat, int numCat) {
  //Print titles for Table 1
  out << setw(20) << left << "Category";
  out << setw(15) << left << "Total %";
  out << setw(12) << left << "How Many";
  out << setw(15) << left << "Each Worth" << endl;

  int i;
  for (i = 0; i < numCat; i++) {
    out << setw(20) << left << cat[i].name;
    out << setw(15) << left << cat[i].totalPercent;
    out << setw(12) << left << cat[i].howMany;
    out << left << static_cast<int>(cat[i].percentEach) << "% ";
    out << "(" << fixed << showpoint << setprecision(2)
    << (cat[i].percentEach)/100;
    out << ")" << endl;
  }
  out << endl;
}

//prints lines of content for table 2
//had to be initialized above the readNumGrades function
//otherwise caused scope issues because this function is called inside
//readNumGrades
void printNumGrades(ofstream& out, cat_t* cat, int num, int* grades) {

    int j;
    out << setw(20) << left << cat[num].name;
    out << setw(15) << left << cat[num].howMany;
    for (j = 0; j < cat[num].howMany; j++) {
      out << grades[j] << " ";
    }
    out << endl;
}

//prints table 2 titles and reads info to print table 2 content
//uses two int pointers for int arrays to store the grades for each
//assignment graded so far
void readNumGrades(ifstream& input2, ofstream& out, cat_t* cat, int numCat2) {
  //Print titles for Table 2
  out << setw(20) << left << "Category";
  out << setw(15) << left << "#Graded";
  out << setw(12) << left << "The grades";
  out << endl;

  int i, j;
  //initialize int pointers
  int* grades;
  int* gradeTotal = new int[numCat2];
  //loop reads in the name of the categories, how many grades,
  //fills the grade arrays with the grades received,
  //and then prints all info line-by-line
  for (i = 0; i < numCat2; i++) {
    input2 >> cat[i].name;
    input2 >> cat[i].howMany;
    grades = new int[cat[i].howMany];
    for (j = 0; j < cat[i].howMany; j++) {
      input2 >> grades[j];
      gradeTotal[i] = gradeTotal[i] + grades[j];
    }
    //tried adding a member to the struct named "total"
    //but compiler was being weird so i used the one member
    //that *luckily* was unused after table 1
    cat[i].totalPercent = gradeTotal[i];
    printNumGrades(out, cat, i, grades);
  }
  out << endl;
}

//prints table 3
//uses previously acquired cat information
//and repeats the same printing process
void printPoints(ofstream& out, cat_t* cat, int numCat) {
  //Print titles for Table
  out << setw(20) << left << "Category";
  out << setw(15) << left << "Total Grades *";
  out << setw(15) << left << "Each Worth = Points for Category" << endl;

  int i;
  double totalSoFar;
  //loop prints the total of grades received, what each is worth
  //and the points you have gained for each category
  for (i = 0; i < numCat; i++) {
    out << setw(20) << left << cat[i].name;
    out << setw(15) << left << cat[i].totalPercent;
    out << setw(13) << left << setprecision(4) << (cat[i].percentEach) / 100;
    out << setw(19) << left << fixed << showpoint << setprecision(2)
    << (cat[i].totalPercent) * ((cat[i].percentEach)/100);
    out << endl;
    //Calculate total points so far
  totalSoFar = totalSoFar + (cat[i].totalPercent) * ((cat[i].percentEach)/100);
  }
  //print total points so far
  out << setw(50) << right << "Total Points thus far    " << totalSoFar << endl;
  out << endl;
}

//prints table 4 and the final grade
//uses previously acquired cat information
//and repeats the same printing process
void printPercent(ofstream& out, cat_t* cat, int numCat) {
  //Print titles for Table
  out << setw(20) << left << "Category";
  out << setw(15) << left << "#Graded";
  out << setw(15) << left << "Each Worth";
  out << setw(6) << left << "What%";
  out << endl;

  //var declarations
  int i;
  double total;
  double totalSoFar;
  //loop prints name, #graded, how much each is worth, and
  //the total percent graded so far
  for (i = 0; i < numCat; i++) {
    out << setw(20) << left << cat[i].name;
    out << setw(15) << left << cat[i].howMany;
    out << setw(15) << left << setprecision(4) << (cat[i].percentEach) / 100;
    out << setw(6) << left << setprecision(4)
    << (cat[i].howMany) * ((cat[i].percentEach) / 100);
    out << endl;
    //Calculate total points and total percent of grades for final grade
    total = total + (cat[i].howMany) * ((cat[i].percentEach)/100);
    totalSoFar = totalSoFar + (cat[i].totalPercent) * ((cat[i].percentEach)/100);
  }
  //prints total percent so far
  out << setw(50) << right << "Total    " << total << endl;
  out << endl;

  //simple division for final grade call
  out << "Final Grade is: " << totalSoFar / 2.0000 << "/" << total << " = "
  << (totalSoFar / 2.0000) / total;
}
