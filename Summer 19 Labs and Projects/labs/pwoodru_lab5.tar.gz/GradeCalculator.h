/****************
Patrick Woodrum
pwoodru
CpSc 1020 Sm19
Lab 5
TA: Nushrat H
****************/
using namespace std;
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

typedef struct category {
  string name;
  int totalPercent;
  int howMany;
  double percentEach;
} cat_t;

//Number 1 on Instructions

//Reads test.txt info to print the first table of grade info
void readGradeBasis(ifstream& input1, cat_t* cat, int numCat);
//Uses info from readGradeBasis to print to the output file
void printGradeBasis(ofstream& out, cat_t* cat, int numCat);

//Number 2

//printNumGrades is used inside readNumGrades, so print had to be declared first
//this function prints line-by-line the info from readNumGrades
void printNumGrades(ofstream& out, cat_t* cat, int num, int* grades);
//Reads from gradesSoFar.txt to print second table to output
void readNumGrades(ifstream& input2, ofstream& out, cat_t* cat, int numCat2);

//Number 3
//Prints table 3 with the same cat info from table 2
void printPoints(ofstream& out, cat_t* cat, int numCat);

//Number 4 & 5
//Prints table 4 and the final grade using the same info
//from cat table 2 and 3
void printPercent(ofstream& out, cat_t* cat, int numCat);
